//============================================================================
// Name        : Banking.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<iomanip>
#include "Banking.h"
using namespace std;

//default banking constructor
Banking::Banking() {
	initialDep = monthlyDep = annualInt = months = years = 0;
	totalAmt = intAmt = yearTotInt = 0;
}

//constructor with parameters
Banking::Banking(float t_initialDep, float t_monthlyDep, float t_annualInt, float t_years) {
	SetInitialDep(t_initialDep);
	SetMonthlyDep(t_monthlyDep);
	SetAnnualInt(t_annualInt);
	SetYears(t_years);
}

//setters
void Banking::SetInitialDep(float t_initialDep) {
	initialDep = t_initialDep;
}

void Banking::SetMonthlyDep(float t_monthlyDep) {
	monthlyDep = t_monthlyDep;
}

void Banking::SetAnnualInt(float t_annualInt) {
	annualInt = t_annualInt;
}

void Banking::SetYears(float t_years) {
	years = t_years;
}

void Banking::SetMonths(float t_months) {
	months = t_months;
}

//getters
double Banking::GetInitialDep() {
	return initialDep;
}

double Banking::GetMonthlyDep() {
	return monthlyDep;
}

double Banking::GetAnnualInt() {
	return annualInt;
}

double Banking::GetYears() {
	return years;
}

double Banking::GetMonths() {
	return months;
}

//display form for user
void DisplayForm() {
	cout << "*************************\n";
	cout << "********Data Input*******\n";
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";
	cout << endl << endl;
}

//get user input
void Banking::GetUserInput() {
	cout << "*************************\n";
	cout << "********Data Input*******\n";
	cout << "Initial Investment Amount: \n";
	cin >> initialDep;
	SetInitialDep(initialDep);
	cout << "Monthly Deposit: \n";
	cin >> monthlyDep;
	SetMonthlyDep(monthlyDep);
	cout << "Annual Interest: \n";
	cin >> annualInt;
	SetAnnualInt(annualInt);
	cout << "Number of years: \n";
	cin >> years;
	SetYears(years);
	months = years * 12;
	SetMonths(months);
}

void Banking::DisplayWithoutMonthly() {
	//set total amount to initial deposit
	totalAmt = initialDep;

	//display yearly data with no monthly deposits
	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";
	for (int i =0; i < years; ++i) {
		//calculate yearly interest
		intAmt = (totalAmt) * ((annualInt / 100));

		//calculate year end total
		totalAmt = totalAmt + intAmt;

		//set fixed precision 2 for dollars
		cout << (i + 1) << "\t\t" << fixed << setprecision(2) << totalAmt << "\t\t\t" << intAmt << "\n";
	}
}

void Banking::DisplayWithMonthly() {
	//set totalAmt to initialDep
	totalAmt = initialDep;

	//display year data with monthly deposits
	cout << "\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";
	for (int i = 0; i < years; ++i) {
		//set yearly interest to zero at the start of every year
		yearTotInt = 0;
		for (int j = 0; j < 12; ++j) {
			//calculate the monthly interest
			intAmt = (totalAmt + monthlyDep) * ((annualInt / 100) / 12);

			//calculate interest at the end of the month
			yearTotInt = yearTotInt + intAmt;

			//calculate total at the end of the month
			totalAmt = totalAmt + monthlyDep + intAmt;

		}
		cout << (i + 1) << "\t\t" << fixed << setprecision(2) << totalAmt << "\t\t\t" << yearTotInt << "\n";
	}
}

int main() {
	Banking MyBanking;

	DisplayForm();
	MyBanking.GetUserInput();
	system("PAUSE");
	MyBanking.DisplayWithoutMonthly();
	MyBanking.DisplayWithMonthly();
	return 0;
}
