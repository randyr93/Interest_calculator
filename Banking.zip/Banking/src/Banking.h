/*
 * Banking.h
 *
 *  Created on: Aug 1, 2020
 *      Author: 1742171_snhu
 */

#ifndef BANKING_H_
#define BANKING_H_
#include<iomanip>

//Define banking class
class Banking {
	//declare variables
	public:
	Banking();
	Banking(float t_initialDep, float t_monthlyDep, float t_annualInt, float t_years);
	void SetInitialDep(float t_initialDep);
	void SetMonthlyDep(float t_monthlyDep);
	void SetAnnualInt(float t_annualInt);
	void SetYears(float t_years);
	void SetMonths(float t_months);
	double GetInitialDep();
	double GetMonthlyDep();
	double GetAnnualInt();
	double GetYears();
	double GetMonths();
	void GetUserInput();
	void DisplayWithoutMonthly();
	void DisplayWithMonthly();



	private:
	// variables for storing input
	float initialDep, monthlyDep, annualInt, months, years;
	//variables for calculations
	float totalAmt, intAmt, yearTotInt;
};
#endif /* BANKING_H_ */
